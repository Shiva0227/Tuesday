package com.cg.Service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.Dao.BankDao;
import com.cg.entity.Account;
import com.cg.entity.Customer;
@Service
@Transactional

public class BankServiceImpl implements BankService{

	@Autowired
	BankDao bankDao;
	@Override
	public Customer addCustomer( Customer customer)  {
		return bankDao.addCustomer(customer);
		
	}
	@Override
	public Account addAccount( Account account)  {
		return bankDao.addAccount(account);
		
	}

	@Override
	public Account showBalance(int accno) {
		
		return bankDao.showBalance(accno);
	}

	@Override
	public Account deposit(int accNo, double balance) {
	
		return bankDao.deposit(accNo, balance);
	}

	@Override
	public Account withDraw(int accNo, double balance) {
	
		return bankDao.withDraw(accNo, balance);
	}

	@Override
	public List<Account> getBankAcc() {
		
		return bankDao.getBankAcc();
	}

	public Account fundTransfer(int accno1,int accno2,double balance)
	{
		return bankDao.fundTransfer(accno1,accno2,balance);
		
	}
	public Account printTransaction(int acno)
	{
		return bankDao.printTransaction(acno);
		
	}

	
}
