package com.cg.Service;

import java.util.List;

import com.cg.entity.Account;
import com.cg.entity.Customer;

public interface BankService {
	public Customer addCustomer( Customer customer) ;
	public Account addAccount( Account account) ;
	public Account showBalance(int accno);
	public Account deposit(int accNo, double balance);
	public Account withDraw(int accNo, double balance) ;
	public List<Account> getBankAcc();
	public Account fundTransfer(int accno1,int accno2,double balance);
	public Account printTransaction(int acno);
}
