package com.cg.Dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;


import com.cg.entity.Account;
import com.cg.entity.Customer;

@Repository
public class BankDaoImpl implements BankDao{

	@PersistenceContext
	private EntityManager entityManager;
	@Override
	public Customer addCustomer( Customer customer) {
	
		entityManager.persist(customer);
		entityManager.flush();
		return customer;
		
	}
	@Override
	public Account addAccount(Account account)
	{
		entityManager.persist(account);
		entityManager.flush();
		return account;
	}

	@Override
	public Account showBalance(int accno) {
		
	  Account acc=   entityManager.find(Account.class,accno);
	  System.out.println(acc);
	         return acc;
	}
	

	@Override
	public Account deposit(int accNo, double balance)
	{
		 Account account=   entityManager.find(Account.class,accNo);
		 double balance1=account.getBalance();
		 double amount=balance1+balance;
		 account.setBalance(amount);
		 entityManager.merge(account);
		 return account;
	}
	@Override
	public Account withDraw(int accNo, double balance) {
		 Account account=   entityManager.find(Account.class,accNo);
		 double balance1=account.getBalance();
		 double amount=balance1-balance;
		 account.setBalance(amount);
		 entityManager.merge(account);
		 return account;
		
	}

	@Override
	public List<Account> getBankAcc() {

		TypedQuery<Account> query=entityManager.createQuery("Select account from Account account",Account.class);
		
		return query.getResultList();
	}

	@Override
public Account fundTransfer(int accNo1,int accNo2,double balance) {
Account account1=entityManager.find(Account.class, accNo1);
Account account2=entityManager.find(Account.class, accNo2);
double bal1=account1.getBalance();
double bal2=account2.getBalance();
if(bal1>balance) {
	double amount1=bal1-balance;
 double amount2=bal2+balance;

	account1.setBalance(amount1);

account2.setBalance(amount2);

entityManager.merge(account1);
entityManager.merge(account2);

}else {
	System.out.println("insufficient amount");
}
return account1;
}
	



	@Override
public Account printTransaction(int acno) {
		 Account account=entityManager.find(Account.class, acno);
		 return account;
	}
}
