package com.cg.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Account1")
public class Account implements Serializable {

	
		/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
		private double balance;
		@Id
		private int accno;


	public Account()
	{
		super();
	}

		@Override
		public String toString() {
			return "Account [balance=" + balance + ", accno=" + accno + "]";
		}
		
		
		public Account(double balance, int accno) {
			super();
			this.balance = balance;
			this.accno = accno;
		}


		public double getBalance() {
			return balance;
		}
		public void setBalance(double balance) {
			this.balance = balance;
		}
		public int getAccno() {
			return accno;
		}
		public void setAccno(int accNo2) {
			this.accno = accNo2;
		}

		}

