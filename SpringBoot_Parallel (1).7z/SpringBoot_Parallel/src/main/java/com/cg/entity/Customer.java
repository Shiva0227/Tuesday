package com.cg.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Customer1")
public class Customer implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String cusName;
	@Id
	private long cusNo;
	private String age;
private String accountType;
private int accno;	
public Customer()
{
	super();
}
public Customer(String cusName, long cusNo, String age, String accountType, int accno) {
	super();
	this.cusName = cusName;
	this.cusNo = cusNo;
	this.age = age;
	this.accountType = accountType;
	this.accno = accno;
}


	
	public String getAccountType() {
	return accountType;
}

public void setAccountType(String accountType) {
	this.accountType = accountType;
}


	

	@Override
public String toString() {
	return "Customer [cusName=" + cusName + ", cusNo=" + cusNo + ", age=" + age + ", accountType=" + accountType
			+ ", accno=" + accno + "]";
}




	public int getAccno() {
		return accno;
	}



	public void setAccno(int accno) {
		this.accno = accno;
	}







	public String getAge() {
		return age;
	}

	

	public String getCusName() {
		return cusName;
	}
	public void setCusName(String cusName) {
		this.cusName = cusName;
	}
	public long getCusNo() {
		return cusNo;
	}
	public void setCusNo(long cusNo) {
		this.cusNo = cusNo;
	}
	
	public void setAge(String age2) {
		this.age = age2;
	}
}
