package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;


import com.cg.Service.BankService;
import com.cg.entity.Account;
import com.cg.entity.Customer;


@RestController
public class BankController {

	
	@Autowired
	BankService bankService;
	
	@RequestMapping(value="/createAccount/{cusName}/{cusNo}/{age}/{accountType}/{balance}",headers="Accept=application/json",
			 method = RequestMethod.POST) 
	public String createAccount(@PathVariable String cusName,@PathVariable long cusNo,@PathVariable String age,@PathVariable String accountType,@PathVariable double balance)
		 {
Customer customer=new Customer();
Account account=new Account();
	customer.setCusName(cusName);
	customer.setCusNo(cusNo);
	customer.setAge(age);
	customer.setAccountType(accountType);
	int accNo1=(int)(Math. random() * 1364381123 + 1364381123);
     customer.setAccno(accNo1);
     account.setBalance(balance);
     account.setAccno(accNo1);
	bankService.addAccount(account);
	bankService.addCustomer(customer);
String res="WELCOME XYZ BANK  "+" "+cusName+ "YOUR ACCOUNT BALANCE IS SUCCESFULLY CREATED";
	return res;

	}
	@RequestMapping(value = "/showBalance/{accNo}", method = RequestMethod.GET,headers="Accept=application/json")
	public String getBalance(@PathVariable int accNo) {
		List<Account> list=bankService.getBankAcc();
		System.out.println(list);
		if(list.contains(accNo))
		{
	Account account=	bankService.showBalance(accNo);
	String res="your account balance is "+account.getBalance();
		return res;
		
		}
		else
		{
			String res1="Invalid Account Number";
			return res1;
		}
     }
	@RequestMapping(value = "/AccountDetails",method = RequestMethod.GET,headers="Accept=application/json")
	public List<Account> getAllDetails(Model model) {
		
		
		return bankService.getBankAcc();
		
	}
	
	
    @RequestMapping(value="/deposit/{accNo}/{amount}",method=RequestMethod.GET,headers="Accept=application/json")
public String deposit(@PathVariable int accNo,@PathVariable double amount) {
    	Account account=bankService.showBalance(accNo);
  String res="your balance is"+account.getAccno();
   Account account1=bankService.deposit(accNo, amount);
  
  String res1="Amount is deposited sucessfully!!!"+account1.getBalance();
  return res1;
}
    
    @RequestMapping(value="/withDraw/{acno}/{amount}",method=RequestMethod.GET,headers="Accept=application/json")
public String withDraw(@PathVariable int acno,@PathVariable double amount) {
    	Account account=bankService.showBalance(acno);


Account account1= bankService.withDraw(acno, amount);
String res="Amount is withdraw sucessfully!!!"+account1.getBalance();
return res;
}
    
    
    @RequestMapping(value = "/fundtransfer/{acno1}/{acno2}/{amount}",method=RequestMethod.GET,headers="Accept=application/json")
    public Account fundtransfer(@PathVariable int acno1,@PathVariable int acno2,@PathVariable double amount) {
    	Account account=bankService.fundTransfer(acno1, acno2, amount);
    	return account;
    }
    
    @RequestMapping(value="/printtransaction/{acno}",method=RequestMethod.GET,headers="Accept=application/json")
public Account getaccdetails(@PathVariable int acno) {
    	Account account=bankService.printTransaction(acno);
    	return account;
    }
}
    



