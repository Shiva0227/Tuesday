package com.cg.SpringBoot_Parallel;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootParallelApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootParallelApplication.class, args);
	}

}
