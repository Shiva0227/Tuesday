package stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;


public class stepdef 
{
	WebDriver d;
	
	@Before
	public void befo()
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\sa17\\Documents\\Selenium\\chromedriver.exe");
		d=new ChromeDriver();
	}
	@Given("^open Ksrtc web site$")
	public void open_Ksrtc_web_site() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		/*
		 * System.setProperty("webdriver.chrome.driver",
		 * "C:\\Users\\sa17\\Documents\\Selenium\\chromedriver.exe"); d=new
		 * ChromeDriver();
		 */
		d.get("http://www.Ksrtc.in/oprs-web/");
		d.manage().window().maximize();
	}

	@When("^user inputs Username$")
	public void user_inputs_Username() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		
		d.findElement(By.linkText("Sign In")).click();
		Thread.sleep(2000);
		d.findElement(By.xpath("//*[@id=\"userName\"]")).sendKeys("mah@yahoo.com");
		//*[@id="bookingsForm"]/div/div/div/div[1]/label
	}

	@When("^user inputs password$")
	public void user_inputs_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		d.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("mysore15");
		d.findElement(By.xpath("//*[@id=\"submitBtn\"]")).click();
		//*[@id="bookingsForm"]/div/div/div/div[1]/label
		//*[@id="submitBtn"]
	}

	@Then("^Login should be succesfull$")
	public void login_should_be_succesfull() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		boolean a=d.findElement(By.linkText("Logout")).isDisplayed();
		if(a)
		{
			System.out.println("login success for valid name and valid password No defect");
		}
		else
		{
			System.out.println("login not success for valid name and valid password A defect");
		}
	}

	
	@When("^user inputs wrong password$")
	public void user_inputs_wrong_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
		
		d.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("mysore16");
		d.findElement(By.xpath("//*[@id=\"submitBtn\"]")).click();
	}

	@Then("^Login should fail$")
	public void login_should_fail() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
		
		boolean text2=d.getPageSource().contains("Login incorrect. Please try again");
		//Assert.assertEquals("Login incorrect. Please try again",text2);
		if(text2)
		{
			System.out.println("Login not successful");
		}
		else
		{
			System.out.println("Login Not successfull -A defect");
		}
	}
	
	@After
	public void close()
	{
		d.close();
	}
	}

	

