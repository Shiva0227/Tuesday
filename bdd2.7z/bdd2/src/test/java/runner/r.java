package runner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.Plugin;
import cucumber.api.junit.Cucumber;
import cucumber.runtime.Glue;



	
	@RunWith(Cucumber.class)
	@CucumberOptions(
			features= {"C:\\Users\\sa17\\eclipse-workspace\\bdd2\\src\\test\\java\\feature\\a.feature"}
			,glue=  {"C:\\Users\\sa17\\eclipse-workspace\\bdd2\\src\\test\\java\\stepdef\\stepdef.java"}
			,plugin= {"pretty","html:target/Shiva-report"}
			,monochrome=true
					,tags= {"@sanity,@smoke"}
					,dryRun=true
					)
	public class r {
		
	}
